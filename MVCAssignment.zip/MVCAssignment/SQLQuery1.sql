﻿create table Customer
(ID int primary key identity,
Name varchar(50),
DOB date,
Address varchar(100),
Gender varchar(10),
Email varchar(50),
State varchar(50))

select * from Customer

insert into Customer values('Ryan Bell', '1/20/99', '123 Street', 'Male', 'ryan@mail.com', 'New York')
﻿using MVCAssignment.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVCAssignment.Controllers
{
    public class CustomerController : Controller
    {
        ICustomerRepository _repo;

        public CustomerController(ICustomerRepository repo)
        {
            _repo = repo;
        }

        public IActionResult Index()
        {
            return View(_repo.ViewCustomer());
        }

        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Add(Customer customer)
        {
            if(ModelState.IsValid)
            {
                _repo.AddCustomer(customer);
                return RedirectToAction("Index");
            }
            return View();
        }

        public IActionResult Delete(int Id)
        {
            return View(_repo.GetCustomer(Id));
        }

        [HttpPost]
        public IActionResult ConfirmDelete(int Id)
        {
            _repo.DeleteCustomer(Id);
            return RedirectToAction("Index");
        }

        public IActionResult Edit(int Id)
        {
            return View(_repo.GetCustomer(Id));
        }

        [HttpPost]
        public IActionResult UpdateCustomer(Customer customer)
        {
            if (ModelState.IsValid)
            {
                _repo.UpdateCustomer(customer);
                return RedirectToAction("Index");
            }
            return View();
        }

        public IActionResult Search()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Search(string State)
        {
            return View(_repo.GetCustomersByState(State));
        }

    }
}

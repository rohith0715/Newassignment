﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVCAssignment.Models
{
    public class CustomerRepository:ICustomerRepository
    {
        CustomerContext _context;
        public CustomerRepository(CustomerContext context)
        {
            _context = context;
        }

        public List<Customer> ViewCustomer()
        {
            return _context.Customer.ToList();
        }
        public int AddCustomer(Customer customer)
        {
            _context.Customer.Add(customer);
            _context.SaveChanges();
            return customer.ID;
        }

        public Customer GetCustomer(int Id)
        {
            return _context.Customer.Find(Id);
            //return _context.Employee.Where{ a->a.ID == Id).FirstOrDefault;
        }

        public List<Customer> GetCustomersByState(string State)
        {
            return _context.Customer.Where(a => a.State == State).ToList();
        }

        public int DeleteCustomer(int Id)
        {
            _context.Customer.Remove(GetCustomer(Id));
            _context.SaveChanges();
            return 1;
        }

        public int UpdateCustomer(Customer customer)
        {
            _context.Entry(customer).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            _context.SaveChanges();
            return 1;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVCAssignment.Models
{
    public interface ICustomerRepository
    {
        public List<Customer> ViewCustomer();
        int AddCustomer(Customer customer);
        Customer GetCustomer(int Id);
        List<Customer> GetCustomersByState(string State);
        int DeleteCustomer(int Id);
        int UpdateCustomer(Customer customer);
    }
}
